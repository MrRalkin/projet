package classes

class ActionResult (
        var isSuccess: Boolean = true,
        var successMessage: String = "",
        var errorMessage: String = "",
    )
