package interfaces.user

interface IRole {
    var id:Int
    var role:String
}