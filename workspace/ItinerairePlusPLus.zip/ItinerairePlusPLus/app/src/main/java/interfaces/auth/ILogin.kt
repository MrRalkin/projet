package interfaces.auth

interface ILogin {
    var email:String
    var password:String
}