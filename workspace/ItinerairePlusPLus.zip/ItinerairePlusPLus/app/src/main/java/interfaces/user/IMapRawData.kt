package interfaces.user

import java.util.Date

interface IMapRawData {
    var destinationId:String
    var created:Long
    var rawData:String
}


