package interfaces.auth

interface IRegister {
    var name:String
    var email:String
    var password:String

}